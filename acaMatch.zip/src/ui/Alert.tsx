function Alert() {
  return <div>Alert</div>;
}

export default Alert;

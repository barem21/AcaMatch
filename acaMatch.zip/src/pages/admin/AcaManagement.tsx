function AcaManagement() {
  return <div>AcaManagement</div>;
}

export default AcaManagement;
